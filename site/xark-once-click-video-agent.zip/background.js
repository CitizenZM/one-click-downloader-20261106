import { videoUrls, dedupeKey } from "./urls.js";

const HOST = "com.barron.oneclick_dl";
let port = null;
let seq = 0;
let inflight = 0;
const pending = new Map();
const jobs = new Map(); // live queue, mirrored to storage for the dashboard
let jobSeq = 0;
let devMode = false;
let idleTimer = null;
let lastHeal = 0;
let flushTimer = null;
let chain = Promise.resolve(); // serialises read-modify-write on storage
const locked = (fn) => (chain = chain.then(fn, fn));

// ---- native host (one long-lived port; replies matched by id) ----
function connect() {
  if (port) return port;
  port = chrome.runtime.connectNative(HOST);
  port.onMessage.addListener((m) => {
    if (m.type === "reload") return chrome.runtime.reload(); // dev builds only (host sends it when ~/.oneclick-dev exists)
    const p = pending.get(m.id);
    if (m.type === "progress") return p && p.onProgress && p.onProgress(m.pct);
    if (p) { pending.delete(m.id); p.resolve(m); }
    idleClose();
  });
  port.onDisconnect.addListener(() => {
    const err = (chrome.runtime.lastError && chrome.runtime.lastError.message) || "Helper disconnected";
    port = null;
    for (const p of pending.values()) p.reject(new Error(err));
    pending.clear();
  });
  return port;
}

// Release the helper process after a quiet minute (dev builds keep it for auto-reload).
function idleClose() {
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => { if (port && !pending.size && !devMode) { port.disconnect(); port = null; } }, 60000);
  if (idleTimer.unref) idleTimer.unref(); // Node (tests) only; a no-op in the browser
}

function call(msg, onProgress) {
  return new Promise((resolve, reject) => {
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error("Helper did not answer in time")); }, 20 * 60000);
    pending.set(id, { resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); }, onProgress });
    try { connect().postMessage({ ...msg, id }); } catch (e) { pending.delete(id); reject(e); }
  });
}

// Tell the helper which build is running; keep the port open only in dev mode (auto-reload).
async function hello() {
  try {
    const r = await call({ type: "hello", version: chrome.runtime.getManifest().version });
    devMode = !!r.dev;
    if (!r.dev && port) { port.disconnect(); port = null; }
  } catch { /* helper not installed: the dashboard explains how to set it up */ }
}

// ---- storage ----
async function get(key, fallback) {
  const r = await chrome.storage.local.get(key);
  return r[key] ?? fallback;
}
const addToLibrary = (meta) => locked(async () => {
  const lib = await get("library", []);
  const url = meta.webpage_url;
  const caption = String(meta.description || "").split("\n")[0].trim();
  const title = /^(Video|Photo) by /.test(meta.title || "") && caption ? caption.slice(0, 100) : meta.title;
  const num = (x) => (Number.isFinite(Number(x)) ? Number(x) : null);
  const entry = { ...meta, title, platform: meta.extractor_key || "Other", url, at: Date.now(),
    duration: num(meta.duration), view_count: num(meta.view_count), like_count: num(meta.like_count),
    comment_count: num(meta.comment_count), channel_follower_count: num(meta.channel_follower_count) };
  const i = lib.findIndex((v) => v.url === url);
  if (i >= 0) lib[i] = entry; else lib.push(entry);
  await chrome.storage.local.set({ library: lib.slice(-5000) }); // bounded: no unlimitedStorage needed
});
const addError = (url, error) => locked(async () => {
  const errs = (await get("errors", [])).slice(-49);
  errs.push({ url: String(url).replace(/[?#].*$/, ""), error: String(error).slice(0, 300), at: Date.now() }); // no query tokens
  await chrome.storage.local.set({ errors: errs });
});
function setJob(id, patch) {
  jobs.set(id, { ...jobs.get(id), ...patch });
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    for (const [k, j] of jobs) if (jobs.size > 30 && (j.state === "done" || j.state === "error")) jobs.delete(k);
    chrome.storage.local.set({ jobs: [...jobs.values()] });
  }, 250);
}

// ---- UI helpers ----
function badge() {
  chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
  chrome.action.setBadgeText({ text: inflight ? String(inflight) : "" });
}
function notify(title, message) {
  chrome.notifications.create({ type: "basic", iconUrl: "icon.png", title, message });
}

// ---- actions ----
const active = new Map(); // dedupeKey -> promise: the same video clicked twice while running is one download
function download(url, force = false) {
  const key = dedupeKey(url);
  if (active.has(key)) return active.get(key);
  const p = downloadNow(url, force).finally(() => active.delete(key));
  active.set(key, p);
  return p;
}
async function downloadNow(url, force = false) {
  const { quality = "best", folder = "", naming = "creator-title-id", skipDuplicates = true } = await get("settings", {});
  if (!force && skipDuplicates) {
    const key = dedupeKey(url);
    const seen = (await get("library", [])).find((v) => v.file && dedupeKey(v.url) === key);
    if (seen) return { ok: true, skipped: true, meta: seen };
  }
  const job = ++jobSeq;
  setJob(job, { id: job, url, state: "queued", pct: 0, at: Date.now() });
  inflight++; badge();
  try {
    const send = () => call({ url, quality, folder, naming }, (pct) => setJob(job, { state: "running", pct }));
    let r = await send();
    // an old yt-dlp is the usual cause of sudden 403s: update once an hour at most, then retry
    if (!r.ok && /update yt-dlp/.test(r.error || "") && Date.now() - lastHeal > 3600000) {
      lastHeal = Date.now();
      await call({ type: "update" }).catch(() => {});
      r = await send();
    }
    if (r.ok) await addToLibrary(r.meta); else await addError(url, r.error);
    setJob(job, r.ok ? { state: "done", pct: 100 } : { state: "error", error: r.error });
    return r;
  } catch (e) {
    await addError(url, e.message);
    setJob(job, { state: "error", error: e.message });
    return { ok: false, error: e.message };
  } finally {
    inflight--; badge();
  }
}

async function oneClick(tab) {
  if (!/^https?:\/\//.test((tab && tab.url) || "")) { notify("Not a page", "Open a video page first."); return { ok: false, error: "Not a page" }; }
  const r = await download(tab.url, true); // a direct click always downloads
  if (r.ok) notify("Saved", (r.meta && r.meta.file) || "Download complete");
  else notify("Download failed", r.error + (/disconnect|not found|Specified native/i.test(r.error) ? " (open the dashboard to set up the helper)" : ""));
  return { ok: !!r.ok, error: r.error };
}

async function downloadAll(tab) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => [...document.links].map((a) => a.href) });
  const urls = videoUrls((res && res.result) || []);
  if (!urls.length) return notify("No videos found", "No TikTok, Instagram, YouTube or X video links on this page.");
  notify("Queued", `${urls.length} videos`);
  const results = await Promise.all(urls.map((u) => download(u)));
  const skipped = results.filter((r) => r.skipped).length;
  const ok = results.filter((r) => r.ok).length - skipped;
  notify("Batch finished", `${ok} saved${skipped ? `, ${skipped} already saved` : ""}, ${results.length - ok - skipped} failed`);
}

const openDashboard = () => chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });

chrome.action.onClicked.addListener(oneClick); // only fires if the popup is removed
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== "download-current") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) oneClick(tab);
});

async function maybeUpdate() {
  const { autoUpdate = true } = await get("settings", {});
  if (!autoUpdate || Date.now() - (await get("lastUpdate", 0)) < 7 * 86400000) return;
  const r = await call({ type: "update" });
  await chrome.storage.local.set({ lastUpdate: Date.now(), updateResult: r.output || "" });
}
const schedule = () => chrome.alarms.create("update", { periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((a) => a.name === "update" && maybeUpdate().catch(() => {}));

chrome.runtime.onStartup.addListener(() => { hello(); schedule(); });
chrome.runtime.onInstalled.addListener(() => {
  hello(); schedule();
  chrome.contextMenus.create({ id: "dl-link", title: "Download video from this link", contexts: ["link"] });
  chrome.contextMenus.create({ id: "select", title: "Select videos on this page…", contexts: ["action", "page"] });
  chrome.contextMenus.create({ id: "dl-all", title: "Download all videos on this page", contexts: ["action", "page"] });
  chrome.contextMenus.create({ id: "dashboard", title: "Open library & insights", contexts: ["action"] });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "dl-link") return oneClick({ ...tab, url: info.linkUrl });
  if (info.menuItemId === "dl-all") return downloadAll(tab);
  if (info.menuItemId === "select") return chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["select.js"] }).catch((e) => notify("Cannot select here", String(e.message || e)));
  if (info.menuItemId === "dashboard") return openDashboard();
});

// ---- optional in-page button (content script is registered only after the user opts in) ----
async function setButtons(on) {
  try { await chrome.scripting.unregisterContentScripts({ ids: ["oneclick-button"] }); } catch { /* none registered */ }
  if (!on) return { ok: true };
  const origins = (chrome.runtime.getManifest().optional_host_permissions || []).filter((o) => !o.includes("anthropic.com"));
  await chrome.scripting.registerContentScripts([{ id: "oneclick-button", matches: origins, js: ["content.js"], runAt: "document_idle", persistAcrossSessions: true }]);
  return { ok: true };
}

function pageState({ href, hrefs }) {
  if (videoUrls([href]).length) return { kind: "single" };
  const n = videoUrls(hrefs || []).length;
  return n >= 2 ? { kind: "batch", n } : { kind: null };
}

async function pageDownload({ href, hrefs, folder }) {
  if (videoUrls([href]).length) {
    const r = await download(href, true);
    return r.ok ? { ok: 1, skipped: 0, failed: 0 } : { ok: 0, failed: 1, error: r.error };
  }
  const { ok, skipped, failed } = await downloadMany(videoUrls(hrefs || []), folder);
  return { ok, skipped, failed };
}

// Collections: a video's `folder` is a plain name; `folders` holds names that exist even when empty.
const cleanFolder = (f) => String(f || "").trim().slice(0, 60);
const addFolderName = (name) => locked(async () => {
  const f = cleanFolder(name);
  if (!f) return { error: "Enter a name" };
  const list = await get("folders", []);
  if (!list.includes(f)) await chrome.storage.local.set({ folders: [...list, f].slice(0, 200) });
  return { ok: true };
});
const deleteFolder = (name) => locked(async () => {
  const f = cleanFolder(name);
  await chrome.storage.local.set({ folders: (await get("folders", [])).filter((x) => x !== f), library: (await get("library", [])).map((v) => (v.folder === f ? { ...v, folder: undefined } : v)) });
  return { ok: true };
});
async function moveToFolder(urls, folder) {
  const f = cleanFolder(folder), keys = new Set(urls.map(dedupeKey));
  if (f) await addFolderName(f);
  return libEdit((lib) => lib.map((v) => (keys.has(dedupeKey(v.url)) ? { ...v, folder: f || undefined } : v)));
}
const summary = (rs) => ({ ok: rs.filter((r) => r.ok && !r.skipped).length, skipped: rs.filter((r) => r.skipped).length, failed: rs.filter((r) => !r.ok).length });
async function downloadMany(urls, folder) {
  const rs = await Promise.all(urls.map((u) => download(u)));
  if (cleanFolder(folder)) await moveToFolder(urls.filter((_, i) => rs[i].ok), folder);
  return { rs, ...summary(rs) };
}

// "Latest N from this profile": the helper lists the URLs, then each goes through the normal download path.
async function expandDownload({ url, limit }) {
  const r = await call({ type: "expand", url, limit });
  if (!r.ok) return { error: r.error };
  const urls = videoUrls(r.urls, 100); // same allowlist as every other batch path
  const rs = await Promise.all(urls.map((u) => download(u)));
  return { found: urls.length, ok: rs.filter((x) => x.ok && !x.skipped).length, skipped: rs.filter((x) => x.skipped).length, failed: rs.filter((x) => !x.ok).length };
}

// library edits run here so they share the storage lock with new downloads
const libEdit = (fn) => locked(async () => {
  const lib = await get("library", []);
  await chrome.storage.local.set({ library: fn(lib) });
  return { ok: true };
});

// dashboard / content script -> background
const CONTENT_TYPES = ["page-state", "page-download"];
chrome.runtime.onMessage.addListener((m, sender, send) => {
  // privileged actions only from our own pages; the content script may only ask about / download its own page
  const fromExtensionPage = typeof sender.url === "string" && sender.url.startsWith(chrome.runtime.getURL(""));
  if (CONTENT_TYPES.includes(m.type) ? !(sender.tab || fromExtensionPage) : !fromExtensionPage) { send({ error: "not allowed" }); return false; }
  if (m.type === "page-state") { send(pageState(m)); return false; }
  const run = m.type === "page-download" ? pageDownload(m)
    : m.type === "expand-download" ? expandDownload(m)
    : m.type === "lib-delete" ? libEdit((lib) => lib.filter((v) => v.url !== m.url))
    : m.type === "lib-note" ? libEdit((lib) => lib.map((v) => (v.url === m.url ? { ...v, note: String(m.note || "").slice(0, 500) } : v)))
    : m.type === "buttons" ? setButtons(!!m.on)
    : m.type === "ping" || m.type === "update" ? call({ type: m.type })
    : m.type === "download" ? downloadMany(videoUrls(m.urls || [], 200), m.folder).then(({ ok, skipped, failed }) => ({ ok, skipped, failed }))
    : m.type === "download-one" ? oneClick({ url: m.url })
    : m.type === "lib-folder" ? moveToFolder(videoUrls(m.urls || [], 500), m.folder)
    : m.type === "folder-add" ? addFolderName(m.name)
    : m.type === "folder-delete" ? deleteFolder(m.name)
    : null;
  if (!run) return false;
  run.then(send, (e) => send({ error: e.message }));
  return true;
});
